pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
  repositories {
    google(); mavenCentral()
    // Quando a Stone liberar o SDK, o repositório deles entra aqui (vem no e-mail de parceiro)
  }
}
rootProject.name = "BuffetBoardPOS"
include(":app")
