#!/bin/bash
# Roda no GitHub: monta o APK e prepara os arquivos da atualização automática
set -o pipefail
if ! gradle :app:assembleRelease --no-daemon 2>&1 | tee build.log; then
  # Mostra o erro em português na página do resumo (fácil de tirar print)
  { echo "## ❌ Erro ao gerar o APK"; echo "Tire um print deste quadro e mande pro Claude."; echo '```';
    grep -E -A3 "^e: |error:|What went wrong|Could not|Cannot|Unresolved|Duplicate|Manifest merger|Failed|failed|Keystore|keystore" build.log | grep -v "^> Task" | head -40;
    echo '```'; } >> "${GITHUB_STEP_SUMMARY:-/dev/stdout}"
  exit 1
fi
mkdir -p saida
cp app/build/outputs/apk/release/app-release.apk saida/BuffetBoardPOS.apk
echo "{\"versao\": ${GITHUB_RUN_NUMBER:-1}}" > saida/versao.json
