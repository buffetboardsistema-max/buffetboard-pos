#!/bin/bash
# Roda no GitHub: monta o APK e prepara os arquivos da atualização automática
set -e
gradle :app:assembleRelease --no-daemon
mkdir -p saida
cp app/build/outputs/apk/release/app-release.apk saida/BuffetBoardPOS.apk
echo "{\"versao\": ${GITHUB_RUN_NUMBER:-1}}" > saida/versao.json
