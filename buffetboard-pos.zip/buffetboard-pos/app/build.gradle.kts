plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  namespace = "br.com.buffetboard.pos"
  compileSdk = 34
  defaultConfig {
    applicationId = "br.com.buffetboard.buffetboardpos.app" // padrão Stone: br.com.Empresa.App.livre
    minSdk = 23          // exigência Stone/Cielo: Android 6.0+ (API 23)
    targetSdk = 34
    versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
    versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    // Cielo: vêm dos Secrets do GitHub, nunca escritos aqui
    buildConfigField("String", "CIELO_CLIENT_ID", "\"" + (System.getenv("CIELO_CLIENT_ID") ?: "") + "\"")
    buildConfigField("String", "CIELO_ACCESS_TOKEN", "\"" + (System.getenv("CIELO_ACCESS_TOKEN") ?: "") + "\"")
  }
  // chave fixa: assim cada versão nova instala POR CIMA da anterior
  signingConfigs { create("bb") { storeFile = file("bb-pos.jks"); storePassword = "buffetpos123"; keyAlias = "bbpos"; keyPassword = "buffetpos123" } }
  buildTypes {
    getByName("debug") { signingConfig = signingConfigs.getByName("bb") }
    getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("bb") }
  }
  buildFeatures { buildConfig = true }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  // implementation("br.com.stone:stone-sdk:<versão>")  // liberar quando a Stone aprovar o parceiro
}
