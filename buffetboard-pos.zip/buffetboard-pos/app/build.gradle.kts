plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  namespace = "br.com.buffetboard.pos"
  compileSdk = 34
  defaultConfig {
    applicationId = "br.com.buffetboard.pos"
    minSdk = 22          // maquininhas Stone rodam Android 5.1+
    targetSdk = 34
    versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
    versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
  }
  // chave fixa: assim cada versão nova instala POR CIMA da anterior
  signingConfigs { create("bb") { storeFile = file("bb-pos.jks"); storePassword = "buffetpos123"; keyAlias = "bbpos"; keyPassword = "buffetpos123" } }
  buildTypes {
    getByName("debug") { signingConfig = signingConfigs.getByName("bb") }
    getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("bb") }
  }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  // implementation("br.com.stone:stone-sdk:<versão>")  // liberar quando a Stone aprovar o parceiro
  // PagBank (Moderninha Smart): kit oficial PlugPagServiceWrapper 1.35.0, arquivo dentro do projeto
  implementation(files("libs/pagbank-plugpag-wrapper-1.35.0.aar"))
  implementation("androidx.core:core:1.12.0")             // o kit do PagBank usa o FileProvider do androidx
  implementation("io.reactivex.rxjava2:rxjava:2.2.21")      // usado internamente pelo kit do PagBank
  // Mercado Pago (Point Smart / SmartApps): kit oficial nativesdk 7.3.1, arquivo dentro do projeto
  implementation(files("libs/mercadopago-nativesdk-7.3.1.aar"))
  implementation("com.google.code.gson:gson:2.10.1")        // usado internamente pelo kit do Mercado Pago
}
