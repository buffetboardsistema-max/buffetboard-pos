plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  namespace = "br.com.buffetboard.pos"
  compileSdk = 34
  defaultConfig {
    applicationId = "br.com.buffetboard.pos"
    minSdk = 22          // maquininhas Stone rodam Android 5.1+
    targetSdk = 34
    versionCode = 1
    versionName = "1.0"
  }
  buildTypes { release { isMinifyEnabled = false } }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  // implementation("br.com.stone:stone-sdk:<versão>")  // liberar quando a Stone aprovar o parceiro
}
