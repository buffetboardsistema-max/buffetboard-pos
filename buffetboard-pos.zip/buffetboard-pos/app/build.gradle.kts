plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  namespace = "br.com.buffetboard.pos"
  compileSdk = 34
  defaultConfig {
    applicationId = "br.com.buffetboard.pos"
    minSdk = 22          // maquininhas Stone rodam Android 5.1+
    targetSdk = 34
    versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
    versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
  }
  // chave fixa: assim cada versão nova instala POR CIMA da anterior
  signingConfigs { create("bb") { storeFile = file("bb-pos.jks"); storePassword = "buffetpos123"; keyAlias = "bbpos"; keyPassword = "buffetpos123" } }
  buildTypes {
    getByName("debug") { signingConfig = signingConfigs.getByName("bb") }
    getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("bb") }
  }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  // implementation("br.com.stone:stone-sdk:<versão>")  // liberar quando a Stone aprovar o parceiro
}
