plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
  namespace = "br.com.buffetboard.pos"
  compileSdk = 34
  defaultConfig {
    applicationId = "br.com.buffetboard.buffetboardpos.app" // padrão Stone: br.com.Empresa.App.livre
    minSdk = 23          // exigência Stone/Cielo: Android 6.0+ (API 23)
    targetSdk = 34
    versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
    versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    // Cielo: vêm dos Secrets do GitHub, nunca escritos aqui
    buildConfigField("String", "CIELO_CLIENT_ID", "\"" + (System.getenv("CIELO_CLIENT_ID") ?: "") + "\"")
    buildConfigField("String", "CIELO_ACCESS_TOKEN", "\"" + (System.getenv("CIELO_ACCESS_TOKEN") ?: "") + "\"")
    buildConfigField("String", "POS_PING_KEY", "\"" + (System.getenv("POS_PING_KEY") ?: "") + "\"")
  }
  // chave definitiva (Cielo/Stone não aceitam troca): vem dos Secrets do GitHub, nunca fica no código
  signingConfigs { create("bb") { storeFile = file("release.jks"); storePassword = (System.getenv("POS_KEYSTORE_PASS") ?: "").trim(); keyAlias = "bbpos"; keyPassword = (System.getenv("POS_KEYSTORE_PASS") ?: "").trim() } }
  buildTypes {
    getByName("debug") { signingConfig = signingConfigs.getByName("bb") }
    getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("bb") }
  }
  buildFeatures { buildConfig = true }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
  // implementation("br.com.stone:stone-sdk:<versão>")  // liberar quando a Stone aprovar o parceiro
}
