package br.com.buffetboard.pos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import java.io.File
import java.io.FileOutputStream

/**
 * Ponte com a maquininha. Descobre sozinha em qual aparelho o app está:
 *  - PagBank (Moderninha Smart): kit oficial PlugPag, já pronto no código
 *  - Mercado Pago (Point Smart): kit oficial nativesdk (SmartApps), já pronto no código
 *  - Cielo (Smart / LIO): por deep link (lio://), sem kit dentro do APK
 *  - Stone: liberar quando a Stone aprovar o parceiro (SDK de POS)
 *  - Celular comum / outra: só modo teste
 * Enquanto MODO_TESTE = true nada é cobrado de verdade, em nenhuma máquina.
 */
object Maquina {
  const val MODO_TESTE = true
  /** Client ID da aplicação "Pagamentos presenciais / Point" em Suas integrações do Mercado Pago (não é segredo) */
  const val MP_CLIENT_ID = "3876752926809160"

  data class Resultado(val aprovado: Boolean, val bandeira: String = "", val codigo: String = "", val erro: String = "")

  private var ctx: Context? = null
  /** chamar no onCreate da tela principal */
  fun iniciar(c: Context) {
    ctx = c.applicationContext
    if (qual() == "mercadopago" && MP_CLIENT_ID.isNotEmpty()) MercadoPago.iniciar(c.applicationContext as android.app.Application)
  }

  /** "pagbank", "mercadopago", "stone" ou "" */
  fun qual(): String {
    val c = ctx ?: return ""
    fun tem(p: String) = try { c.packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false }
    if (Build.VERSION.SDK_INT >= 23 && tem("br.com.uol.pagseguro.plugpagservice")) return "pagbank"
    if (Build.VERSION.SDK_INT >= 23 && (tem("com.mercadopago.smartpos") || tem("com.mercadopago.android.isp_smart_mediator"))) return "mercadopago"
    if (Cielo.disponivel(c)) return "cielo"
    if (Build.MANUFACTURER.contains("stone", true) || tem("br.com.stone.posandroid.paymentapp")) return "stone"
    return ""
  }

  fun nome(): String = when (qual()) { "pagbank" -> "PagBank"; "mercadopago" -> "Mercado Pago"; "cielo" -> "Cielo"; "stone" -> "Stone"; else -> "" }

  /** valor em reais; tipo = "credito", "debito" ou "pix" */
  fun cobrarCartao(valor: Double, tipo: String, fim: (Resultado) -> Unit) {
    if (MODO_TESTE) { fim(Resultado(true, "TESTE", "T" + System.currentTimeMillis() % 100000)); return }
    when (qual()) {
      "pagbank" -> Thread { fim(PagBank.cobrar(ctx!!, valor, tipo)) }.start()
      "mercadopago" -> MercadoPago.cobrar(valor, tipo, fim)
      "cielo" -> Cielo.cobrar(ctx!!, valor, tipo, fim)
      "stone" -> fim(Resultado(false, erro = "Stone ainda não liberada"))   // TODO SDK Stone
      else -> fim(Resultado(false, erro = "Este aparelho não é uma maquininha compatível"))
    }
  }

  fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) {
    if (MODO_TESTE) { fim(true, "Modo teste: impressão simulada"); return }
    when (qual()) {
      "pagbank" -> Thread { val r = PagBank.imprimir(ctx!!, linhas); fim(r.first, r.second) }.start()
      "mercadopago" -> MercadoPago.imprimir(linhas, fim)
      "cielo" -> Cielo.imprimir(ctx!!, linhas, fim)
      "stone" -> fim(false, "Stone ainda não liberada")                    // TODO SDK Stone (impressora)
      else -> fim(false, "Este aparelho não tem impressora compatível")
    }
  }

  // PagBank: código pronto guardado (pos-kits-guardados), volta quando testarmos numa Moderninha
  private object PagBank {
    fun cobrar(c: Context, valor: Double, tipo: String) = Resultado(false, erro = "PagBank ainda não liberado")
    fun imprimir(c: Context, linhas: List<String>) = Pair(false, "PagBank ainda não liberado")
  }

  /** a impressora das maquininhas imprime imagem: desenha as linhas numa imagem de 384 px (largura do papel) */
  private fun imagem(linhas: List<String>): Bitmap {
    val larg = 384; val alt = 34
    val bmp = Bitmap.createBitmap(larg, alt * linhas.size + 20, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp); cv.drawColor(Color.WHITE)
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 24f; typeface = Typeface.MONOSPACE }
    linhas.forEachIndexed { i, l -> cv.drawText(l, 6f, (alt * (i + 1)).toFloat(), p) }
    return bmp
  }

  // Mercado Pago: código pronto guardado (pos-kits-guardados), volta quando o Mercado Pago liberar a Point de teste
  private object MercadoPago {
    fun iniciar(app: android.app.Application) {}
    fun cobrar(valor: Double, tipo: String, fim: (Resultado) -> Unit) = fim(Resultado(false, erro = "Mercado Pago ainda não liberado"))
    fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) = fim(false, "Mercado Pago ainda não liberado")
  }

  /** a tela principal chama isto quando a Cielo devolve o resultado (bbpos://...) */
  fun retorno(uri: android.net.Uri?) { Cielo.retorno(uri) }

  /**
   * Cielo Smart / LIO — integração por deep link (manual "Integração Local via Deep Link").
   * Client-ID e Access-Token NÃO ficam no código: vêm dos "Secrets" do GitHub
   * (CIELO_CLIENT_ID e CIELO_ACCESS_TOKEN) na hora de gerar o APK.
   */
  private object Cielo {
    private var fimPag: ((Resultado) -> Unit)? = null
    private var fimImp: ((Boolean, String) -> Unit)? = null
    private fun b64(s: String) = android.util.Base64.encodeToString(s.toByteArray(), android.util.Base64.NO_WRAP)

    fun disponivel(c: Context): Boolean = try {
      val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("lio://payment"))
      c.packageManager.queryIntentActivities(i, 0).isNotEmpty()
    } catch (e: Exception) { false }

    private fun abrir(c: Context, uri: String) {
      val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(uri))
      i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
      c.startActivity(i)
    }

    fun cobrar(c: Context, valor: Double, tipo: String, fim: (Resultado) -> Unit) {
      if (BuildConfig.CIELO_CLIENT_ID.isEmpty() || BuildConfig.CIELO_ACCESS_TOKEN.isEmpty()) { fim(Resultado(false, erro = "Cielo sem Client-ID configurado")); return }
      val centavos = Math.round(valor * 100)
      val codigo = when (tipo) { "debito" -> "DEBITO_AVISTA"; "pix" -> "PIX"; else -> "CREDITO_AVISTA" }
      val req = org.json.JSONObject()
        .put("accessToken", BuildConfig.CIELO_ACCESS_TOKEN).put("clientID", BuildConfig.CIELO_CLIENT_ID)
        .put("email", "").put("installments", 0).put("paymentCode", codigo).put("value", centavos.toString())
        .put("reference", "BB" + System.currentTimeMillis())
        .put("items", org.json.JSONArray().put(org.json.JSONObject().put("name", "Venda Buffet Board").put("quantity", 1).put("sku", "BB").put("unitOfMeasure", "unidade").put("unitPrice", centavos)))
      fimPag = fim
      try { abrir(c, "lio://payment?request=" + b64(req.toString()) + "&urlCallback=bbpos://pagamento") }
      catch (e: Exception) { fimPag = null; fim(Resultado(false, erro = "Não abriu o pagamento da Cielo")) }
    }

    fun imprimir(c: Context, linhas: List<String>, fim: (Boolean, String) -> Unit) {
      val req = org.json.JSONObject().put("operation", "PRINT_TEXT")
        .put("styles", org.json.JSONArray().put(org.json.JSONObject()))
        .put("value", org.json.JSONArray().put(linhas.joinToString("\n")))
      fimImp = fim
      try { abrir(c, "lio://print?request=" + b64(req.toString()) + "&urlCallback=bbpos://impressao") }
      catch (e: Exception) { fimImp = null; fim(false, "Não abriu a impressora da Cielo") }
    }

    fun retorno(uri: android.net.Uri?) {
      if (uri == null || uri.scheme != "bbpos") return
      val json = try { org.json.JSONObject(String(android.util.Base64.decode(uri.getQueryParameter("response") ?: "", android.util.Base64.DEFAULT))) } catch (e: Exception) { null }
      if (uri.host == "impressao") { val f = fimImp; fimImp = null; f?.invoke(json != null && json.optString("code", "0") == "0", "Impresso"); return }
      val f = fimPag; fimPag = null
      val pag = json?.optJSONArray("payments")?.optJSONObject(0)
      val status = json?.optString("status", "") ?: ""
      if (pag == null || status.equals("CANCELED", true) || status.equals("ENTERED", true)) { f?.invoke(Resultado(false, erro = "Pagamento cancelado")); return }
      f?.invoke(Resultado(true, pag.optString("brand", "Cielo"), pag.optString("authCode", pag.optString("cieloCode", ""))))
    }
  }
}
