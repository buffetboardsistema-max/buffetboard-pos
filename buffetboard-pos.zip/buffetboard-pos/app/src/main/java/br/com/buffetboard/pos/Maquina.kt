package br.com.buffetboard.pos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import java.io.File
import java.io.FileOutputStream

/**
 * Ponte com a maquininha. Descobre sozinha em qual aparelho o app está:
 *  - PagBank (Moderninha Smart): kit oficial PlugPag, já pronto no código
 *  - Mercado Pago (Point Smart): kit oficial nativesdk (SmartApps), já pronto no código
 *  - Stone: liberar quando a Stone aprovar o parceiro (SDK de POS)
 *  - Celular comum / outra: só modo teste
 * Enquanto MODO_TESTE = true nada é cobrado de verdade, em nenhuma máquina.
 */
object Maquina {
  const val MODO_TESTE = true
  /** Client ID da aplicação "Pagamentos presenciais / Point" em Suas integrações do Mercado Pago (não é segredo) */
  const val MP_CLIENT_ID = ""

  data class Resultado(val aprovado: Boolean, val bandeira: String = "", val codigo: String = "", val erro: String = "")

  private var ctx: Context? = null
  /** chamar no onCreate da tela principal */
  fun iniciar(c: Context) {
    ctx = c.applicationContext
    if (qual() == "mercadopago" && MP_CLIENT_ID.isNotEmpty()) MercadoPago.iniciar(c.applicationContext as android.app.Application)
  }

  /** "pagbank", "mercadopago", "stone" ou "" */
  fun qual(): String {
    val c = ctx ?: return ""
    fun tem(p: String) = try { c.packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false }
    if (Build.VERSION.SDK_INT >= 23 && tem("br.com.uol.pagseguro.plugpagservice")) return "pagbank"
    if (Build.VERSION.SDK_INT >= 23 && (tem("com.mercadopago.smartpos") || tem("com.mercadopago.android.isp_smart_mediator"))) return "mercadopago"
    if (Build.MANUFACTURER.contains("stone", true) || tem("br.com.stone.posandroid.paymentapp")) return "stone"
    return ""
  }

  fun nome(): String = when (qual()) { "pagbank" -> "PagBank"; "mercadopago" -> "Mercado Pago"; "stone" -> "Stone"; else -> "" }

  /** valor em reais; tipo = "credito", "debito" ou "pix" */
  fun cobrarCartao(valor: Double, tipo: String, fim: (Resultado) -> Unit) {
    if (MODO_TESTE) { fim(Resultado(true, "TESTE", "T" + System.currentTimeMillis() % 100000)); return }
    when (qual()) {
      "pagbank" -> Thread { fim(PagBank.cobrar(ctx!!, valor, tipo)) }.start()
      "mercadopago" -> MercadoPago.cobrar(valor, tipo, fim)
      "stone" -> fim(Resultado(false, erro = "Stone ainda não liberada"))   // TODO SDK Stone
      else -> fim(Resultado(false, erro = "Este aparelho não é uma maquininha compatível"))
    }
  }

  fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) {
    if (MODO_TESTE) { fim(true, "Modo teste: impressão simulada"); return }
    when (qual()) {
      "pagbank" -> Thread { val r = PagBank.imprimir(ctx!!, linhas); fim(r.first, r.second) }.start()
      "mercadopago" -> MercadoPago.imprimir(linhas, fim)
      "stone" -> fim(false, "Stone ainda não liberada")                    // TODO SDK Stone (impressora)
      else -> fim(false, "Este aparelho não tem impressora compatível")
    }
  }

  // PagBank: código pronto guardado (pos-kits-guardados), volta quando testarmos numa Moderninha
  private object PagBank {
    fun cobrar(c: Context, valor: Double, tipo: String) = Resultado(false, erro = "PagBank ainda não liberado")
    fun imprimir(c: Context, linhas: List<String>) = Pair(false, "PagBank ainda não liberado")
  }

  /** a impressora das maquininhas imprime imagem: desenha as linhas numa imagem de 384 px (largura do papel) */
  private fun imagem(linhas: List<String>): Bitmap {
    val larg = 384; val alt = 34
    val bmp = Bitmap.createBitmap(larg, alt * linhas.size + 20, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp); cv.drawColor(Color.WHITE)
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 24f; typeface = Typeface.MONOSPACE }
    linhas.forEachIndexed { i, l -> cv.drawText(l, 6f, (alt * (i + 1)).toFloat(), p) }
    return bmp
  }

  // Mercado Pago: código pronto guardado (pos-kits-guardados), volta quando o Mercado Pago liberar a Point de teste
  private object MercadoPago {
    fun iniciar(app: android.app.Application) {}
    fun cobrar(valor: Double, tipo: String, fim: (Resultado) -> Unit) = fim(Resultado(false, erro = "Mercado Pago ainda não liberado"))
    fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) = fim(false, "Mercado Pago ainda não liberado")
  }
}
