package br.com.buffetboard.pos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import java.io.File
import java.io.FileOutputStream

/**
 * Ponte com a maquininha. Descobre sozinha em qual aparelho o app está:
 *  - PagBank (Moderninha Smart): kit oficial PlugPag, já pronto no código
 *  - Mercado Pago (Point Smart): kit oficial nativesdk (SmartApps), já pronto no código
 *  - Cielo (Smart / LIO): por deep link (lio://), sem kit dentro do APK
 *  - Stone (POS Android): por deep link (payment-app:// e printer-app://), sem kit dentro do APK
 *  - Celular comum / outra: só modo teste
 * Enquanto MODO_TESTE = true nada é cobrado de verdade, em nenhuma máquina.
 */
object Maquina {
  const val MODO_TESTE = true
  /** Client ID da aplicação "Pagamentos presenciais / Point" em Suas integrações do Mercado Pago (não é segredo) */
  const val MP_CLIENT_ID = "3876752926809160"

  data class Resultado(val aprovado: Boolean, val bandeira: String = "", val codigo: String = "", val erro: String = "")

  private var ctx: Context? = null
  /** chamar no onCreate da tela principal */
  fun iniciar(c: Context) {
    ctx = c.applicationContext
    if (qual() == "mercadopago" && MP_CLIENT_ID.isNotEmpty()) MercadoPago.iniciar(c.applicationContext as android.app.Application)
  }

  /** "pagbank", "mercadopago", "stone" ou "" */
  fun qual(): String {
    val c = ctx ?: return ""
    fun tem(p: String) = try { c.packageManager.getPackageInfo(p, 0); true } catch (e: Exception) { false }
    if (Build.VERSION.SDK_INT >= 23 && tem("br.com.uol.pagseguro.plugpagservice")) return "pagbank"
    if (Build.VERSION.SDK_INT >= 23 && (tem("com.mercadopago.smartpos") || tem("com.mercadopago.android.isp_smart_mediator"))) return "mercadopago"
    if (Cielo.disponivel(c)) return "cielo"
    if (Stone.disponivel(c) || Build.MANUFACTURER.contains("stone", true) || tem("br.com.stone.posandroid.paymentapp")) return "stone"
    return ""
  }

  fun nome(): String = when (qual()) { "pagbank" -> "PagBank"; "mercadopago" -> "Mercado Pago"; "cielo" -> "Cielo"; "stone" -> "Stone"; else -> "" }

  /** valor em reais; tipo = "credito", "debito" ou "pix" */
  fun cobrarCartao(valor: Double, tipo: String, fim: (Resultado) -> Unit) {
    if (MODO_TESTE && qual() != "cielo") { fim(Resultado(true, "TESTE", "T" + System.currentTimeMillis() % 100000)); return }
    when (qual()) {
      "pagbank" -> Thread { fim(PagBank.cobrar(ctx!!, valor, tipo)) }.start()
      "mercadopago" -> MercadoPago.cobrar(valor, tipo, fim)
      "cielo" -> Cielo.cobrar(ctx!!, valor, tipo, fim)
      "stone" -> Stone.cobrar(ctx!!, valor, tipo, fim)
      else -> fim(Resultado(false, erro = "Este aparelho não é uma maquininha compatível"))
    }
  }

  fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) {
    if (MODO_TESTE && qual() != "cielo") { fim(true, "Modo teste: impressão simulada"); return }
    when (qual()) {
      "pagbank" -> Thread { val r = PagBank.imprimir(ctx!!, linhas); fim(r.first, r.second) }.start()
      "mercadopago" -> MercadoPago.imprimir(linhas, fim)
      "cielo" -> Cielo.imprimir(ctx!!, linhas, fim)
      "stone" -> Stone.imprimir(ctx!!, linhas, fim)
      else -> fim(false, "Este aparelho não tem impressora compatível")
    }
  }

  // PagBank: código pronto guardado (pos-kits-guardados), volta quando testarmos numa Moderninha
  private object PagBank {
    fun cobrar(c: Context, valor: Double, tipo: String) = Resultado(false, erro = "PagBank ainda não liberado")
    fun imprimir(c: Context, linhas: List<String>) = Pair(false, "PagBank ainda não liberado")
  }

  /** a impressora das maquininhas imprime imagem: desenha as linhas numa imagem de 384 px (largura do papel) */
  private fun imagem(linhas: List<String>): Bitmap {
    val larg = 384; val alt = 34
    val bmp = Bitmap.createBitmap(larg, alt * linhas.size + 20, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp); cv.drawColor(Color.WHITE)
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 24f; typeface = Typeface.MONOSPACE }
    linhas.forEachIndexed { i, l -> cv.drawText(l, 6f, (alt * (i + 1)).toFloat(), p) }
    return bmp
  }

  // Mercado Pago: código pronto guardado (pos-kits-guardados), volta quando o Mercado Pago liberar a Point de teste
  private object MercadoPago {
    fun iniciar(app: android.app.Application) {}
    fun cobrar(valor: Double, tipo: String, fim: (Resultado) -> Unit) = fim(Resultado(false, erro = "Mercado Pago ainda não liberado"))
    fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) = fim(false, "Mercado Pago ainda não liberado")
  }

  /** a tela principal chama isto quando a Cielo devolve o resultado (bbpos://...) */
  fun retorno(uri: android.net.Uri?) {
    if (uri?.host == "pay-response" || uri?.host == "print") Stone.retorno(uri) else Cielo.retorno(uri)
  }

  /**
   * Stone POS Android — integração por Deeplink (doc oficial sdkandroid.stone.com.br).
   * Pagamento: payment-app://pay  → volta em bbpos://pay-response
   * Impressão: printer-app://print → volta em bbpos://print
   * Não precisa de chave no código.
   */
  private object Stone {
    private var fimPag: ((Resultado) -> Unit)? = null
    private var fimImp: ((Boolean, String) -> Unit)? = null

    fun disponivel(c: Context): Boolean = try {
      val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("payment-app://pay"))
      c.packageManager.queryIntentActivities(i, 0).isNotEmpty()
    } catch (e: Exception) { false }

    private fun abrir(c: Context, uri: android.net.Uri) {
      val i = android.content.Intent(android.content.Intent.ACTION_VIEW, uri)
      i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
      c.startActivity(i)
    }

    fun cobrar(c: Context, valor: Double, tipo: String, fim: (Resultado) -> Unit) {
      val centavos = Math.round(valor * 100)
      val t = when (tipo) { "debito" -> "DEBIT"; "pix" -> "PIX"; else -> "CREDIT" }
      val b = android.net.Uri.Builder().scheme("payment-app").authority("pay")
        .appendQueryParameter("return_scheme", "bbpos")
        .appendQueryParameter("amount", centavos.toString())
        .appendQueryParameter("transaction_type", t)
        .appendQueryParameter("editable_amount", "0")
      if (t == "CREDIT") b.appendQueryParameter("installment_type", "NONE")
      fimPag = fim
      try { abrir(c, b.build()) }
      catch (e: Exception) { fimPag = null; fim(Resultado(false, erro = "Não abriu o pagamento da Stone")) }
    }

    fun imprimir(c: Context, linhas: List<String>, fim: (Boolean, String) -> Unit) {
      val arr = org.json.JSONArray()
      linhas.forEach { arr.put(org.json.JSONObject().put("type", "text").put("content", it).put("align", "left").put("size", "medium")) }
      val uri = android.net.Uri.Builder().scheme("printer-app").authority("print")
        .appendQueryParameter("SHOW_FEEDBACK_SCREEN", "false")
        .appendQueryParameter("SCHEME_RETURN", "bbpos")
        .appendQueryParameter("PRINTABLE_CONTENT", arr.toString()).build()
      fimImp = fim
      try { abrir(c, uri) }
      catch (e: Exception) { fimImp = null; fim(false, "Não abriu a impressora da Stone") }
    }

    fun retorno(uri: android.net.Uri) {
      try {
        if (uri.host == "print") {
          val f = fimImp; fimImp = null
          val txt = uri.toString()
          val ok = txt.contains("SUCCESS", true)
          val msg = when {
            ok -> "Impresso"
            txt.contains("OUT_OF_PAPER", true) -> "Sem papel"
            txt.contains("OVERHEATING", true) -> "Impressora quente, espere um pouco"
            txt.contains("LOW_ENERGY", true) -> "Bateria fraca"
            txt.contains("PAPER_JAM", true) -> "Papel enroscado"
            txt.contains("BUSY", true) -> "Impressora ocupada"
            else -> "Erro na impressão"
          }
          f?.invoke(ok, msg); return
        }
        val f = fimPag; fimPag = null
        val code = uri.getQueryParameter("code")
        val sucesso = uri.getQueryParameter("success")
        if (code == "0" && sucesso != "false") {
          f?.invoke(Resultado(true, uri.getQueryParameter("brand") ?: "Stone", uri.getQueryParameter("authorization_code") ?: (uri.getQueryParameter("atk") ?: "")))
        } else {
          val m = uri.getQueryParameter("message") ?: uri.getQueryParameter("reason") ?: "Pagamento cancelado"
          f?.invoke(Resultado(false, erro = m))
        }
      } catch (e: Exception) {
        val f = fimPag; fimPag = null; f?.invoke(Resultado(false, erro = "Erro no retorno da Stone"))
      }
    }
  }

  /**
   * Cielo Smart / LIO — integração por deep link (manual "Integração Local via Deep Link").
   * Client-ID e Access-Token NÃO ficam no código: vêm dos "Secrets" do GitHub
   * (CIELO_CLIENT_ID e CIELO_ACCESS_TOKEN) na hora de gerar o APK.
   */
  private object Cielo {
    private var fimPag: ((Resultado) -> Unit)? = null
    private var fimImp: ((Boolean, String) -> Unit)? = null
    private fun b64(s: String) = android.util.Base64.encodeToString(s.toByteArray(), android.util.Base64.NO_WRAP)

    fun disponivel(c: Context): Boolean = try {
      val pm = c.packageManager
      val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("lio://payment?request=e30=&urlCallback=bbpos://pagamento"))
      val tem = { p: String -> try { pm.getPackageInfo(p, 0); true } catch (e: Exception) { false } }
      pm.queryIntentActivities(i, android.content.pm.PackageManager.MATCH_ALL).isNotEmpty() || tem("com.ads.lio.uriappclient") ||
        pm.getInstalledPackages(0).any { it.packageName.contains("cielo", true) || it.packageName.contains("lio.", true) }
    } catch (e: Exception) { false }

    private fun abrir(c: Context, uri: String) {
      val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(uri))
      i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
      c.startActivity(i)
    }

    fun cobrar(c: Context, valor: Double, tipo: String, fim: (Resultado) -> Unit) {
      // sem credencial: usa valores de teste (o Emulador Cielo não valida)
      val cid = BuildConfig.CIELO_CLIENT_ID.ifEmpty { "EMULADOR" }; val tok = BuildConfig.CIELO_ACCESS_TOKEN.ifEmpty { "EMULADOR" }
      val centavos = Math.round(valor * 100)
      val codigo = when (tipo) { "debito" -> "DEBITO_AVISTA"; "pix" -> "PIX"; else -> "CREDITO_AVISTA" }
      val req = org.json.JSONObject()
        .put("accessToken", tok).put("clientID", cid)
        .put("email", "contato@buffetboard.com.br").put("installments", 0).put("paymentCode", codigo).put("value", centavos.toString())
        .put("reference", "BB" + System.currentTimeMillis())
        .put("items", org.json.JSONArray().put(org.json.JSONObject().put("name", "Venda Buffet Board").put("quantity", 1).put("sku", "BB").put("unitOfMeasure", "unidade").put("unitPrice", centavos)))
      fimPag = fim
      try { abrir(c, "lio://payment?request=" + b64(req.toString()) + "&urlCallback=bbpos://pagamento") }
      catch (e: Exception) { fimPag = null; fim(Resultado(false, erro = "Não abriu o pagamento da Cielo")) }
    }

    fun imprimir(c: Context, linhas: List<String>, fim: (Boolean, String) -> Unit) {
      val req = org.json.JSONObject().put("operation", "PRINT_TEXT")
        .put("styles", org.json.JSONArray().put(org.json.JSONObject()))
        .put("value", org.json.JSONArray().put(linhas.joinToString("\n")))
      fimImp = fim
      try { abrir(c, "lio://print?request=" + b64(req.toString()) + "&urlCallback=bbpos://impressao") }
      catch (e: Exception) { fimImp = null; fim(false, "Não abriu a impressora da Cielo") }
    }

    fun retorno(uri: android.net.Uri?) {
      if (uri == null || uri.scheme != "bbpos") return
      val bruto = (uri.getQueryParameter("response") ?: "").trim()
      fun lerJson(t: String): org.json.JSONObject? = try { org.json.JSONObject(t) } catch (e: Exception) { null }
      val json = lerJson(bruto)
        ?: try { lerJson(String(android.util.Base64.decode(bruto.replace(' ', '+'), android.util.Base64.DEFAULT))) } catch (e: Exception) { null }
        ?: try { lerJson(String(android.util.Base64.decode(bruto, android.util.Base64.URL_SAFE))) } catch (e: Exception) { null }
      if (uri.host == "impressao") { val f = fimImp; fimImp = null; f?.invoke(json != null && json.optString("code", "0") == "0", "Impresso"); return }
      val f = fimPag; fimPag = null
      val pag = json?.optJSONArray("payments")?.optJSONObject(0)
      val status = json?.optString("status", "") ?: ""
      if (pag == null || status.equals("CANCELED", true) || status.equals("ENTERED", true)) {
        // mostra o que a Cielo respondeu, para sabermos o motivo
        val txt = try { String(android.util.Base64.decode(bruto.replace(' ', '+'), android.util.Base64.DEFAULT)) } catch (e: Exception) { bruto }
        val motivo = json?.toString()?.take(300) ?: txt.take(300)
        f?.invoke(Resultado(false, erro = "Cielo: " + motivo)); return
      }
      f?.invoke(Resultado(true, pag.optString("brand", "Cielo"), pag.optString("authCode", pag.optString("cieloCode", ""))))
    }
  }
}
