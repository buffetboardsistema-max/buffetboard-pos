package br.com.buffetboard.pos

/**
 * Ponte com a maquininha. Hoje funciona em MODO TESTE (sem cobrar de verdade).
 * Quando a Stone aprovar o parceiro e liberar o SDK, só esta classe muda:
 *  - cobrarCartao -> StoneTransaction (débito/crédito) do SDK de POS da Stone
 *  - imprimir     -> impressora térmica da maquininha (SDK Stone)
 */
object Maquina {
  const val MODO_TESTE = true

  data class Resultado(val aprovado: Boolean, val bandeira: String = "", val codigo: String = "", val erro: String = "")

  /** valor em reais; tipo = "credito" ou "debito" */
  fun cobrarCartao(valor: Double, tipo: String, fim: (Resultado) -> Unit) {
    if (MODO_TESTE) { fim(Resultado(true, "TESTE", "T" + System.currentTimeMillis() % 100000)); return }
    // TODO SDK Stone
  }

  fun imprimir(linhas: List<String>, fim: (Boolean, String) -> Unit) {
    if (MODO_TESTE) { fim(true, "Modo teste: impressão simulada"); return }
    // TODO SDK Stone (impressora)
  }
}
