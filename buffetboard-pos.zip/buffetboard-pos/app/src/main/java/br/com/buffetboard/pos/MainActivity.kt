package br.com.buffetboard.pos

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

/** Buffet Board POS — telas nativas (a Stone não aceita WebView). Caixa, Delivery e Etiqueta. */
class MainActivity : Activity() {
  private lateinit var api: Api
  private val escopo = MainScope()
  private val OURO = Color.parseColor("#C89B3C"); private val TINTA = Color.parseColor("#2B2A28"); private val FUNDO = Color.parseColor("#F6F2EA")

  override fun onCreate(s: Bundle?) { super.onCreate(s); api = Api(this); if (api.logado) inicio() else login() }
  override fun onDestroy() { escopo.cancel(); super.onDestroy() }

  // ---------- peças de tela ----------
  private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
  private fun brl(v: Double) = "R$ " + String.format(Locale("pt", "BR"), "%.2f", v).replace('.', ',')
  private fun tela(titulo: String, voltar: (() -> Unit)? = null): LinearLayout {
    val raiz = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(FUNDO) }
    val topo = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#1C1B19")); setPadding(dp(14), dp(14), dp(14), dp(14)); gravity = Gravity.CENTER_VERTICAL }
    if (voltar != null) topo.addView(TextView(this).apply { text = "‹ "; textSize = 26f; setTextColor(OURO); setOnClickListener { voltar() } })
    topo.addView(TextView(this).apply { text = titulo; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
    raiz.addView(topo)
    val corpo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)) }
    raiz.addView(ScrollView(this).apply { addView(corpo) }, LinearLayout.LayoutParams(-1, 0, 1f))
    setContentView(raiz); return corpo
  }
  private fun botao(txt: String, cor: Int = OURO, corTxt: Int = TINTA, acao: () -> Unit) = Button(this).apply {
    text = txt; isAllCaps = false; textSize = 17f; setTextColor(corTxt); typeface = Typeface.DEFAULT_BOLD
    background = GradientDrawable().apply { setColor(cor); cornerRadius = dp(12).toFloat() }
    layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
    setOnClickListener { acao() }
  }
  private fun texto(t: String, tam: Float = 15f, negrito: Boolean = false) = TextView(this).apply { text = t; textSize = tam; setTextColor(TINTA); if (negrito) typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(6), 0, dp(6)) }
  private fun campo(dica: String, tipo: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply { hint = dica; inputType = tipo; textSize = 17f
    background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(10).toFloat(); setStroke(dp(1), Color.parseColor("#E2DCCF")) }
    setPadding(dp(14), dp(14), dp(14), dp(14)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) } }
  private fun aviso(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
  private fun rodar(bloco: suspend () -> Unit) = escopo.launch { try { bloco() } catch (e: Exception) { aviso(e.message ?: "Sem conexão. Tente de novo.") } }

  // ---------- login ----------
  private fun login() {
    val c = tela("Buffet Board")
    c.addView(texto("Entre com a mesma conta do app Buffet Board.", 16f))
    val em = campo("E-mail", InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS); val se = campo("Senha", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
    c.addView(em); c.addView(se)
    c.addView(botao("Entrar") { rodar {
      val e = em.text.toString().trim().lowercase()
      val r = api.post("/auth/entrar", JSONObject().put("email", e).put("senha", se.text.toString()).put("origem", "pos-stone"))
      api.email = e; api.token = r.optString("token"); inicio()
    } })
  }

  // ---------- início ----------
  private fun inicio() {
    val c = tela("Buffet Board")
    c.addView(texto(api.email, 13f))
    if (Maquina.MODO_TESTE) c.addView(texto("⚠️ Modo teste: cartão e impressão simulados.", 13f))
    c.addView(botao("🧾  Caixa") { caixa() })
    c.addView(botao("🛵  Pedidos do delivery") { delivery() })
    c.addView(botao("🏷️  Imprimir etiqueta") { etiqueta() })
    c.addView(botao("Sair", Color.WHITE) { rodar { try { api.post("/auth/sair", JSONObject()) } catch (_: Exception) {}; api.token = ""; login() } })
  }

  // ---------- caixa ----------
  private val comanda = LinkedHashMap<String, Int>()
  private var pratos = JSONArray()
  private fun caixa() {
    val c = tela("🧾 Caixa") { inicio() }
    c.addView(texto("Carregando…"))
    rodar { pratos = api.get("/pdv").optJSONArray("pratos") ?: JSONArray(); desenharCaixa() }
  }
  private fun preco(id: String): Double { for (i in 0 until pratos.length()) { val p = pratos.getJSONObject(i); if (p.optString("id") == id) return p.optDouble("preco", 0.0) }; return 0.0 }
  private fun nome(id: String): String { for (i in 0 until pratos.length()) { val p = pratos.getJSONObject(i); if (p.optString("id") == id) return p.optString("nome") }; return "?" }
  private fun total() = comanda.entries.sumOf { preco(it.key) * it.value }
  private fun desenharCaixa() {
    val c = tela("🧾 Caixa") { comanda.clear(); inicio() }
    if (comanda.isNotEmpty()) {
      c.addView(texto("Comanda", 16f, true))
      comanda.forEach { (id, q) -> c.addView(texto("${q}x ${nome(id)}  ·  ${brl(preco(id) * q)}  (toque pra tirar)").apply { setOnClickListener { if (q > 1) comanda[id] = q - 1 else comanda.remove(id); desenharCaixa() } }) }
      c.addView(texto("Total: ${brl(total())}", 22f, true))
      c.addView(botao("💳  Crédito") { cobrar("credito") }); c.addView(botao("💳  Débito") { cobrar("debito") })
      c.addView(botao("💵  Dinheiro", Color.WHITE) { vender(JSONObject().put("dinheiro", total())) })
      c.addView(botao("Pix (já recebido)", Color.WHITE) { vender(JSONObject().put("pix", total())) })
      c.addView(texto(" "))
    }
    c.addView(texto("Toque no prato para adicionar", 14f))
    for (i in 0 until pratos.length()) {
      val p = pratos.getJSONObject(i); val pr = p.optDouble("preco", 0.0); if (pr <= 0) continue
      c.addView(botao("${p.optString("nome")}   ${brl(pr)}", Color.WHITE) { val id = p.optString("id"); comanda[id] = (comanda[id] ?: 0) + 1; desenharCaixa() })
    }
    if (pratos.length() == 0) c.addView(texto("Nenhum prato com preço. Cadastre no app Buffet Board."))
  }
  private fun cobrar(tipo: String) {
    val v = total()
    Maquina.cobrarCartao(v, tipo) { r -> runOnUiThread { if (r.aprovado) vender(JSONObject().put("cartao", v)) else aviso("Não aprovado: ${r.erro}") } }
  }
  private fun vender(pagamentos: JSONObject) = rodar {
    val itens = JSONArray(); comanda.forEach { (id, q) -> itens.put(JSONObject().put("pratoId", id).put("qtd", q)) }
    val uid = "pos-" + UUID.randomUUID().toString().take(18)  // não duplica se a internet cair e tentar de novo
    val r = api.post("/pdv/venda", JSONObject().put("uid", uid).put("itens", itens).put("pagamentos", pagamentos))
    val vd = r.getJSONObject("venda"); comanda.clear()
    AlertDialog.Builder(this).setTitle("✅ Venda registrada").setMessage("Total ${brl(vd.optDouble("total"))}" + (if (vd.optDouble("troco") > 0) "\nTroco ${brl(vd.optDouble("troco"))}" else "") + "\nJá entrou no Caixa e o estoque baixou.")
      .setPositiveButton("Nova venda") { _, _ -> desenharCaixa() }.show()
  }

  // ---------- delivery ----------
  private fun delivery() {
    val c = tela("🛵 Delivery") { inicio() }; c.addView(texto("Carregando…"))
    rodar {
      val d = api.get("/dl"); val ps = d.optJSONArray("pedidos") ?: JSONArray()
      val c2 = tela("🛵 Delivery") { inicio() }
      c2.addView(botao("🔄  Atualizar", Color.WHITE) { delivery() })
      var n = 0
      for (i in 0 until ps.length()) {
        val p = ps.getJSONObject(i); val st = p.optString("status"); if (st !in listOf("novo", "aceito", "saiu")) continue; n++
        val itens = p.optJSONArray("itens") ?: JSONArray(); val sb = StringBuilder()
        for (k in 0 until itens.length()) { val it = itens.getJSONObject(k); sb.append("${it.optInt("qtd")}x ${it.optString("nome")}\n") }
        c2.addView(texto("#${p.optInt("numero")} · ${p.optString("nome")} · ${brl(p.optDouble("total"))}  [${st}]", 16f, true))
        c2.addView(texto(sb.toString().trim() + (if (p.optString("pagamento").isNotEmpty()) "\nPagamento: ${p.optString("pagamento")}" else "")))
        val prox = mapOf("novo" to ("aceito" to "✅ Aceitar"), "aceito" to ("saiu" to "🛵 Saiu pra entrega"), "saiu" to ("entregue" to "📦 Entregue"))[st]
        if (prox != null) c2.addView(botao(prox.second) { rodar { api.post("/dl/status/${p.optString("id")}", JSONObject().put("status", prox.first)); delivery() } })
        if (st == "saiu" && p.optString("pagamento") == "cartao") c2.addView(botao("💳  Cobrar na entrega", Color.WHITE) {
          Maquina.cobrarCartao(p.optDouble("total"), "credito") { r -> runOnUiThread { if (r.aprovado) aviso("Pago! Marque como entregue.") else aviso("Não aprovado") } } })
      }
      if (n == 0) c2.addView(texto("Nenhum pedido agora 👍", 16f))
    }
  }

  // ---------- etiqueta ----------
  private fun etiqueta() {
    val c = tela("🏷️ Etiqueta") { inicio() }; c.addView(texto("Carregando…"))
    rodar {
      val card = api.get("/cardapio"); val c2 = tela("🏷️ Etiqueta") { inicio() }
      val dias = campo("Validade em dias (ex.: 3)", InputType.TYPE_CLASS_NUMBER).apply { setText("3") }
      c2.addView(texto("Validade", 15f, true)); c2.addView(dias); c2.addView(texto("Escolha o prato:", 15f, true))
      card.keys().forEach { id ->
        val p = card.optJSONObject(id) ?: return@forEach; val nm = p.optString("nome"); if (nm.isEmpty()) return@forEach
        c2.addView(botao(nm, Color.WHITE) {
          val f = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")); val hoje = Date()
          val val_ = Date(hoje.time + (dias.text.toString().toIntOrNull() ?: 3) * 86400000L)
          val al = p.optJSONObject("etiqueta")?.optJSONArray("allergens"); val als = mutableListOf<String>()
          if (al != null) for (k in 0 until al.length()) als.add(al.getJSONObject(k).optString("label"))
          val linhas = listOf(nm.uppercase(), "Preparo: ${f.format(hoje)}", "Validade: ${f.format(val_)}", if (als.isEmpty()) "" else "Alérgenos: " + als.joinToString(", "), "Resp.: ${api.email.substringBefore("@")}")
          Maquina.imprimir(linhas.filter { it.isNotEmpty() }) { ok, msg -> runOnUiThread { aviso(if (ok) "🏷️ $msg" else "Erro: $msg") } }
        })
      }
    }
  }
}
