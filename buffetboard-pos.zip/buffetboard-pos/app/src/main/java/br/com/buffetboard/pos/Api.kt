package br.com.buffetboard.pos

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Fala com o MESMO servidor do app (Render). Mesmas contas, mesmos dados do celular e do PC. */
class Api(ctx: Context) {
  private val pref = ctx.getSharedPreferences("bb", Context.MODE_PRIVATE)
  var email: String get() = pref.getString("email", "") ?: ""; set(v) = pref.edit().putString("email", v).apply()
  var token: String get() = pref.getString("token", "") ?: ""; set(v) = pref.edit().putString("token", v).apply()
  val logado get() = email.isNotEmpty() && token.isNotEmpty()

  suspend fun get(rota: String) = chamar("GET", rota, null)
  suspend fun post(rota: String, corpo: JSONObject) = chamar("POST", rota, corpo)

  private suspend fun chamar(metodo: String, rota: String, corpo: JSONObject?): JSONObject = withContext(Dispatchers.IO) {
    val c = URL(BASE + rota).openConnection() as HttpURLConnection
    c.requestMethod = metodo; c.connectTimeout = 20000; c.readTimeout = 30000
    c.setRequestProperty("Content-Type", "application/json")
    c.setRequestProperty("X-Workspace-Id", email)
    c.setRequestProperty("X-BB-Token", token)
    c.setRequestProperty("X-Origem", "pos-stone")
    if (corpo != null) { c.doOutput = true; c.outputStream.use { it.write(corpo.toString().toByteArray()) } }
    val ok = c.responseCode in 200..299
    val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: "{}"
    val j = try { JSONObject(txt) } catch (e: Exception) { JSONObject() }
    if (!ok) throw Exception(j.optString("error", j.optString("message", "Erro ${c.responseCode}")))
    j
  }
  companion object { const val BASE = "https://buffetboard-backend.onrender.com" }
}
