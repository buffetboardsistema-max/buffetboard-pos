# Buffet Board POS (maquininha Stone)

App Android nativo (Kotlin) para a loja de apps da Stone. Usa o mesmo servidor e as mesmas contas do Buffet Board.

- 🧾 Caixa: escolhe pratos, cobra no cartão (maquininha), dinheiro ou Pix → venda entra no Buffet Board e o estoque baixa.
- 🛵 Delivery: aceita, saiu, entregue, e cobra na entrega.
- 🏷️ Etiqueta: imprime na impressora da maquininha.

**Hoje roda em MODO TESTE** (`Maquina.kt`): cartão e impressão simulados. Quando a Stone liberar o SDK de parceiro, só `Maquina.kt` muda.

O APK é gerado sozinho pelo GitHub (aba **Actions** → "Gerar APK" → baixar em *Artifacts*).
